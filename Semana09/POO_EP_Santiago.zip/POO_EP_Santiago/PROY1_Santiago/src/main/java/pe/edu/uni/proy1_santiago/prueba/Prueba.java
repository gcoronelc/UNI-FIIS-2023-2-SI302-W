package pe.edu.uni.proy1_santiago.prueba;

import pe.edu.uni.proy1_santiago.service.ProyectoService;

public class Prueba {
    public static void main(String[] args) {
        ProyectoService service=new ProyectoService();
        int numeroPerfecto = 28;
        int numeroAmigo1 = 220;
        int numeroAmigo2 = 284;
        int n = 2;
        double x = 1;

        System.out.println(numeroPerfecto + " es un número perfecto: " + service.esNumeroPerfecto(numeroPerfecto));
        System.out.println(numeroAmigo1 + " y " + numeroAmigo2 + " son números amigos: " + service.sonNumerosAmigos(numeroAmigo1, numeroAmigo2));
        System.out.println("La suma de la serie es: " + service.calcularSerie(n, x));    
    }
    
}
