package pe.edu.uni.proy1_santiago;

import pe.edu.uni.proy1_santiago.view.ProyectoView;



public class PROY1_Santiago {

    public static void main(String[] args) {
        ProyectoView.main(args);
    }
}
