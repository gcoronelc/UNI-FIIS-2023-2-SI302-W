package pe.edu.uni.proy1_santiago.service;

public class ProyectoService {
    private int sumaDivisores(int numero) {
        int suma = 1; 
        for (int i = 2; i <= numero / 2; i++) {
            if (numero % i == 0) {
                suma += i;
            }
        }
        return suma;
    }
    public boolean esNumeroPerfecto(int numero) {
        if (numero <= 1) {
            return false;
        }
        
        int sumaDivisores=sumaDivisores(numero);
        
        return sumaDivisores == numero;
    }
    
    public  boolean sonNumerosAmigos(int numero1, int numero2) {
        
        int sumaDivisores1=sumaDivisores(numero1);
        int sumaDivisores2=sumaDivisores(numero2);
        
        return (sumaDivisores1 == numero2) && (sumaDivisores2 == numero1);
    }

    public  double calcularSerie(int n, double x) {
        double resultado = 0.0;
        for (int i = 0; i <= n; i++) {
            resultado += Math.pow(-1, i) * Math.pow(x, 2 * i + 1) / (2 * i + 1);
        }
        resultado = Math.round(resultado*100);
        return resultado/100;
    }
   
}
