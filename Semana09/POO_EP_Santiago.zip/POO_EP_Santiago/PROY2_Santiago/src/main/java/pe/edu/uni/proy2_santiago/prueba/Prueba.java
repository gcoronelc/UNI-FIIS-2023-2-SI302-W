
package pe.edu.uni.proy2_santiago.prueba;

import pe.edu.uni.proy2_santiago.service.VectorService;


public class Prueba {

    public static void main(String[] args) {
        int n = 10;

        VectorService service = new VectorService(n);
        int[] vector3 = service.getVector3();
        int[] vector5 = service.getVector5();
        int[] vectorComun = service.vectorComun();
        int[] vectorUnion = service.vectorUnion();
        
        System.out.print("Vector 3: ");
        for (int i = 0; i < vector3.length; i++) {
            System.out.print(vector3[i]);
            System.out.print((i < vector3.length - 1 ? "," : ""));
        }    
        System.out.println("");
        
        System.out.print("Vector 5: ");
        for (int i = 0; i < vector5.length; i++) {
            System.out.print(vector5[i]);
            System.out.print((i < vector5.length - 1 ? "," : ""));
        }
        System.out.println("");
        
        System.out.print("Vector Comun: ");
        for (int i = 0; i < vectorComun.length; i++) {
            System.out.print(vectorComun[i]);
            System.out.print((i < vectorComun.length - 1 ? "," : ""));
        } 
        System.out.println("");
        
        System.out.print("Vector Union: ");
        for (int i = 0; i < vectorUnion.length; i++) {
            System.out.print(vectorUnion[i]);
            System.out.print((i < vectorUnion.length - 1 ? "," : ""));

        }
    }

}
