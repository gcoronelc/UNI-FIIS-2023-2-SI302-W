/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pe.edu.uni.proy2_santiago;

import pe.edu.uni.proy2_santiago.view.ProyectoView;


public class PROY2_Santiago {

    public static void main(String[] args) {
        ProyectoView.main(args);
    }
}
