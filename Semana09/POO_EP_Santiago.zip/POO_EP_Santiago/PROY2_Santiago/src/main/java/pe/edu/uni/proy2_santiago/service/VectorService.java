
package pe.edu.uni.proy2_santiago.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class VectorService {

    private int n;
    private int[] vector3;
    private int[] vector5;

    public VectorService(int n) {
        this.n = n;
        this.vector3 = new int[n];
        this.vector5 = new int[n];
        generarDatos();
    }

    public void generarDatos() {
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            int numeroRandom;
            do {
                numeroRandom = random.nextInt(41) + 10; // Genera valores en el rango [10, 50]
            } while (numeroRandom % 3 != 0);

            vector3[i] = numeroRandom;

        }
        for (int i = 0; i < n; i++) {
            int numeroRandom;
            do {
                numeroRandom = random.nextInt(41) + 10; // Genera valores en el rango [10, 50]
            } while (numeroRandom % 5 != 0);

            vector5[i] = numeroRandom;

        }
    }

    public int[] getVector3() {
        return vector3;
    }

    public int[] getVector5() {
        return vector5;
    }

    public boolean contieneValor(int[] arreglo, int numero) {
        for (int elemento : arreglo) {
            if (elemento == numero) {
                return true;
            }
        }
        return false;
    }

    public int[] vectorComun() {
        List<Integer> resultado = new ArrayList<>();

        for (int numero : vector3) {
            if (contieneValor(vector5, numero) && !resultado.contains(numero)) {
                resultado.add(numero);
            }
        }
        int[] arreglo = new int[resultado.size()];

        for (int i = 0; i < resultado.size(); i++) {
            arreglo[i] = resultado.get(i);
        }
        return arreglo;
    }

    public int[] vectorUnion() {
        List<Integer> resultado = new ArrayList<>();
        for (int numero : vector3) {
            if (!resultado.contains(numero)) {
                resultado.add(numero);
            }
        }
        for (int numero : vector5) {
            if (!resultado.contains(numero)) {
                resultado.add(numero);
            }
        }

        int[] arreglo = new int[resultado.size()];

        for (int i = 0; i < resultado.size(); i++) {
            arreglo[i] = resultado.get(i);
        }
        return arreglo;
    }
}
